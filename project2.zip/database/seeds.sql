INSERT INTO dog (breed,img,score) VALUES ('pug', 'https://az616578.vo.msecnd.net/files/2016/06/17/636017344804814168-1934845513_PUG.jpg', '5');
INSERT INTO dog (breed,img,score) VALUES ('beagel', 'https://az616578.vo.msecnd.net/files/2016/06/17/636017344804814168-1934845513_PUG.jpg', '4' );
INSERT INTO dog (breed,img,score) VALUES ('pom', 'https://az616578.vo.msecnd.net/files/2016/06/17/636017344804814168-1934845513_PUG.jpg', '3' );
